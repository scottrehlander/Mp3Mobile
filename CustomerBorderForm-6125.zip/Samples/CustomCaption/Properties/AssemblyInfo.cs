﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("CustomCaption")]
[assembly: AssemblyDescription("Lizard Skined Forms Demo")]
